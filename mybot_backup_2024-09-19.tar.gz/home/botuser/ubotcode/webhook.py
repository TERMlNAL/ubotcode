import aiosqlite
import os
import hashlib
import logging
from aiogram import Bot
from fastapi import FastAPI, Form, HTTPException, Request
from fastapi.responses import JSONResponse, HTMLResponse
from dotenv import load_dotenv

# Загрузка переменных окружения
load_dotenv()

# Получение переменных окружения
API_TOKEN = os.getenv('API_TOKEN')
ROBOKASSA_PASSWORD2 = os.getenv('ROBOKASSA_PASSWORD2')

# Настройка логирования
logging.basicConfig(level=logging.INFO)

# Инициализация FastAPI и бота
app = FastAPI()
bot = Bot(token=API_TOKEN)

@app.post("/robokassa/result")
async def robokassa_result(request: Request):
    form = await request.form()
    data = dict(form)
    logging.info(f"Received webhook data: {data}")

    # Проверка наличия необходимых полей
    required_fields = ['OutSum', 'InvId', 'SignatureValue']
    for field in required_fields:
        if field not in data:
            logging.error(f"Missing field: {field}")
            raise HTTPException(status_code=400, detail=f"Missing field: {field}")

    # Валидация подписи
    signature_string = f"{data['OutSum']}:{data['InvId']}:{ROBOKASSA_PASSWORD2}"
    expected_signature = hashlib.md5(signature_string.encode('utf-8')).hexdigest()

    if expected_signature.lower() != data['SignatureValue'].lower():
        logging.error("Invalid signature")
        raise HTTPException(status_code=400, detail="Invalid signature")

    # Обработка платежа
    try:
        InvId_int = int(data['InvId'])
    except ValueError:
        logging.error("Invalid InvId format")
        raise HTTPException(status_code=400, detail="Invalid InvId format")

    async with aiosqlite.connect('users.db') as db:
        async with db.execute("SELECT user_id, tariff, status FROM payments WHERE inv_id=?", (InvId_int,)) as cursor:
            payment = await cursor.fetchone()

        if not payment:
            logging.error(f"Payment with InvId {InvId_int} not found")
            raise HTTPException(status_code=400, detail="Payment not found")

        user_id, tariff, status = payment

        if status == 'completed':
            logging.info("Payment already processed")
            return JSONResponse(content={"status": "OK"})

        # Обновление статуса платежа
        await db.execute("UPDATE payments SET status='completed' WHERE inv_id=?", (InvId_int,))

        # Начисление токенов
        tariff_mapping = {
            'Базовый': 1000,
            'Продвинутый': 2000,
            'Премиум': 3000
        }
        tokens_to_add = tariff_mapping.get(tariff, 0)

        await db.execute(
            "UPDATE users SET tariff=?, tokens_balance = tokens_balance + ? WHERE user_id=?",
            (tariff, tokens_to_add, user_id)
        )
        await db.commit()

    # Отправка сообщения пользователю в Telegram
    try:
        await bot.send_message(
            chat_id=user_id,
            text=f"✅ Вы успешно приобрели тариф **{tariff}**! Ваш баланс токенов пополнен на {tokens_to_add}.",
            parse_mode="Markdown"
        )
        logging.info(f"Message sent to user {user_id}")
    except Exception as e:
        logging.error(f"Error sending message to user {user_id}: {e}")

    return JSONResponse(content={"status": "OK"})

@app.get("/success", response_class=HTMLResponse)
async def robokassa_success():
    html_content = """
    <html>
    <head><title>Оплата успешно завершена</title></head>
    <body>
        <h1>Спасибо за вашу оплату!</h1>
        <p>Вы можете вернуться в Telegram-бот.</p>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content, status_code=200)

@app.get("/fail", response_class=HTMLResponse)
async def robokassa_fail():
    html_content = """
    <html>
    <head><title>Оплата не завершена</title></head>
    <body>
        <h1>Оплата не была завершена.</h1>
        <p>Пожалуйста, попробуйте снова.</p>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content, status_code=200)
